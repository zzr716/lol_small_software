// pages/free/free.js
Page({
  data:{
    heroes: [{
      img: "../img/2.png",
      nickname: "1.Braum 布隆 弗雷尔卓德 Support"
    },{
      img: "../img/3.png",
      nickname: '2.Chogath 科加斯 虚空恐惧 Tank'
    },{
      img: "../img/4.png",
      nickname: '3.Fiora 菲奥娜 无双剑姬 Fighter'
    },{
      img: "../img/5.png",
      nickname: '4.Fizz 菲兹 潮汐海灵 Assassin'
    },{
      img: "../img/6.png",
      nickname: '5.Graves 格雷福斯 法外狂徒 Markman'
    },{
      img: "../img/7.png",
      nickname: '6.Jhin 烬 戏命师 Markman'
    },{
      img: "../img/8.png",
      nickname: '7.Lulu 璐璐 仙灵女巫 Support'
    },{
      img: "../img/9.png",
      nickname: '8.Morgana 莫甘娜 堕落天使 Mage'
    },{
      img: "../img/10.png",
      nickname: '9.Nasus 内瑟斯 沙漠死神 Fighter'
    },{
      img: "../img/11.png",
      nickname: '10.Zed 劫 影流之主 Assassin'
    }]
},
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  }
})
